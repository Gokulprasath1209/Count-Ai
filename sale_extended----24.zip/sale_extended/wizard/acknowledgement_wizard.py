from odoo import models, fields, api, _

class SaleOrderAcknowledgementWizard(models.TransientModel):
    _name = 'sale.order.acknowledgement.wizard'
    _description = 'Sale Order Acknowledgement Wizard'

    order_id = fields.Many2one('sale.order', string='Order', required=True)
    line_ids = fields.One2many(
        'sale.order.acknowledgement.wizard.line', 'wizard_id', string='Products'
    )

    @api.model
    def default_get(self, fields):
        res = super(SaleOrderAcknowledgementWizard, self).default_get(fields)
        active_id = self._context.get('active_id')
        if active_id:
            order = self.env['sale.order'].browse(active_id)
            res.update({'order_id': order.id})
            lines = []
            for line in order.order_line:
                if line.product_id:
                    lines.append((0, 0, {
                        'product_id': line.product_id.id,
                        'quantity': line.product_uom_qty,
                    }))
            res.update({'line_ids': lines})
        return res

    def action_confirm(self):
        self.ensure_one()
        line_vals = []
        for line in self.line_ids:
            if line.product_id and line.quantity > 0:
                line_vals.append((0, 0, {
                    'product_id': line.product_id.id,
                    'quantity': line.quantity,
                }))
        
        if not line_vals:
            raise UserError(_("Please specify quantities for at least one product."))

        self.env['sale.order.acknowledgement'].create({
            'order_id': self.order_id.id,
            'line_ids': line_vals
        })
        return {'type': 'ir.actions.act_window_close'}


class SaleOrderAcknowledgementWizardLine(models.TransientModel):
    _name = 'sale.order.acknowledgement.wizard.line'
    _description = 'Sale Order Acknowledgement Wizard Line'

    wizard_id = fields.Many2one('sale.order.acknowledgement.wizard', string='Wizard')
    product_id = fields.Many2one('product.product', string='Product')
    quantity = fields.Float(string='Received Quantity')
