/** @odoo-module **/

import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { loadJS } from "@web/core/assets";
const { Component, onWillStart, onMounted, useState, useRef, useExternalListener } = owl;

export class CEODashboard extends Component {
    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.state = useState({
            activeTab: 'summary',
            data: {
                revenue: 0,
                spend: 0,
                margin: 0,
                margin_pct: 0,
                inventory: 0,
                projects: { on_track: 0, at_risk: 0, over_budget: 0 },
                approvals: { pending: 0, approved: 0, rejected: 0, blocked_value: 0 },
                bottlenecks: [],
                trends: [],
                top_vendors: [],
                last_updated: "",
                dropdownOpen: false,
                spendView: 'timeline',
                inventoryView: 'split',
                focView: 'trend',
                activeFilter: null, // To track which dropdown is open
                filters: {
                    period: 'Today',
                    project: 'All Projects',
                    client: 'All Clients',
                    vendor: 'All Vendors',
                    warehouse: 'All Warehouses',
                    category: 'All Categories'
                },
                filterOptions: {
                    periods: ['Today', 'This Week', 'This Month', 'This Quarter', 'Custom Range'],
                    projects: ['All Projects', 'PRJ-24-001X', 'PRJ-24-002Y', 'PRJ-24-003Z'],
                    clients: ['All Clients', 'Client A', 'Client B', 'Client C'],
                    vendors: ['All Vendors', 'Material Supplier Ltd', 'Tech Components Co', 'General Parts INC'],
                    warehouses: ['All Warehouses', 'Location A', 'Location B', 'Location C'],
                    categories: ['All Categories', 'Raw Materials', 'Electricals', 'Mechanical']
                },
                money_flow: {
                    outward_spend: { value: 245680, trend: -12.5 },
                    inward_purchase: { value: 312450, trend: 8.2 },
                    payables_pending: { value: 1875320, trend: -5.3 },
                    project_spend: { value: 4523100, trend: 15.7 },
                    foc_cost: { value: 123450, trend: -22.3 },
                    inventory_value: { value: 10200000, trend: 3.1 }
                },
                projects_page: {
                    active_projects: 14,
                    total_budget: 11500000,
                    total_spent: 4523000,
                    project_list: [
                        { id: 'PRJ-2024-001', client: 'Alpha Industries', budget: 2500000, spent: 2150000, balance: 350000, variance: -14.0, status: 'Active' },
                        { id: 'PRJ-2024-002', client: 'Beta Corp', budget: 1800000, spent: 1620000, balance: 180000, variance: -10.0, status: 'Active' },
                        { id: 'PRJ-2024-003', client: 'Gamma Systems', budget: 3200000, spent: 980000, balance: 2220000, variance: -69.4, status: 'Active' },
                        { id: 'PRJ-2024-004', client: 'Delta Tech', budget: 1500000, spent: 1450000, balance: 50000, variance: -3.3, status: 'Active' },
                        { id: 'PRJ-2024-005', client: 'Epsilon Ltd', budget: 2000000, spent: 2100000, balance: -100000, variance: 5.0, status: 'Active' }
                    ],
                    approvals: {
                        pending: 3,
                        approved: 12,
                        rejected: 2,
                        blocked_value: 4500000,
                        bottlenecks: [
                            { id: 'PRJ-2024-006', amount: 1500000, level: 'CFO', expected: 1500000, waiting: 3, status: 'Pending' },
                            { id: 'PRJ-2024-007', amount: 800000, level: 'CEO', expected: 800000, waiting: 7, status: 'Pending' },
                            { id: 'PRJ-2024-008', amount: 2200000, level: 'Finance', expected: 2200000, waiting: 1, status: 'Pending' }
                        ]
                    }
                },
                inventory_page: {
                    total_value: 10200000,
                    split: [
                        { label: 'R&D Stock', value: 3500000, percentage: 34.3, color: '#3b82f6' },
                        { label: 'Moving Stock', value: 5200000, percentage: 51.0, color: '#10b981' },
                        { label: 'Non-Moving Stock', value: 1500000, percentage: 14.7, color: '#ef4444' }
                    ],
                    aging_data: [
                        { label: '0-30 days', value: 6200000, color: '#3b82f6' },
                        { label: '31-90 days', value: 3100000, color: '#3b82f6' },
                        { label: '90+ days', value: 900000, color: '#3b82f6' }
                    ],
                    forecast: {
                        cash_required_30d: 3500000,
                        cards: [
                            { label: 'Next 30 days', forecasted: 3500000, committed: 2100000, pending: 1400000 },
                            { label: 'Next 60 days', forecasted: 6800000, committed: 3900000, pending: 2900000 },
                            { label: 'Next 90 days', forecasted: 9200000, committed: 5200000, pending: 4000000 }
                        ],
                        shortages: {
                            total_at_risk: 750000,
                            items: [
                                { name: 'PCB Boards (Type A)', value: 250000, impact: 'High Impact' },
                                { name: 'Aluminum Sheets', value: 180000, impact: 'Medium Impact' },
                                { name: 'Motor Assembly', value: 320000, impact: 'High Impact' }
                            ]
                        },
                        cash_requirement: 9200000
                    }
                },
                foc_page: {
                    mtd_cost: 123000,
                    ytd_cost: 845000,
                    revenue_pct: 2.37,
                    top_client: 'Alpha Industries',
                    trend: {
                        labels: ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb'],
                        foc_costs: [85000, 92000, 105000, 118000, 134000, 138000, 122000],
                        revenue: [1150000, 1220000, 1340000, 1450000, 1530000, 1560000, 1510000]
                    },
                    clients: [
                        { name: 'Alpha Industries', reason: 'Warranty', value: 45000, reason_type: 'warranty' },
                        { name: 'Beta Corp', reason: 'Goodwill', value: 32000, reason_type: 'goodwill' },
                        { name: 'Gamma Systems', reason: 'Failure', value: 28000, reason_type: 'failure' },
                        { name: 'Delta Tech', reason: 'Warranty', value: 18450, reason_type: 'warranty' }
                    ],
                    machines: [
                        { name: 'CNC-001', value: 38000, failures: 12 },
                        { name: 'LASER-003', value: 29500, failures: 8 },
                        { name: 'PRESS-002', value: 24000, failures: 5 },
                        { name: 'MILL-004', value: 31000, failures: 9 }
                    ]
                },
                forecast_page: {
                    labels: ['Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug'],
                    revenue: [1550000, 1620000, 1780000, 1850000, 1920000, 2050000],
                    target: [1400000, 1500000, 1600000, 1700000, 1800000, 1900000]
                }
            }
        });





        this.trendChartRef = useRef("trendChart");
        this.spendChartRef = useRef("spendChart");
        this.vendorChartRef = useRef("vendorChart");
        this.inventoryChartRef = useRef("inventoryChart");
        this.forecastChartRef = useRef("forecastChart");
        this.focChartRef = useRef("focChart");
        this.businessForecastChartRef = useRef("businessForecastChart");
        this.charts = {};
        useExternalListener(window, 'resize', () => this.renderCharts());

        onWillStart(async () => {
            await loadJS("/web/static/lib/Chart/Chart.js");
            await this.loadData();
        });

        onMounted(() => {
            this.renderCharts();
        });
    }

    async loadData() {
        const data = await this.orm.call("ceo.dashboard", "get_dashboard_data", []);
        Object.assign(this.state.data, data);
    }

    toggleDropdown() {
        this.state.data.dropdownOpen = !this.state.data.dropdownOpen;
    }

    toggleSpendView(view) {
        if (this.state.data.spendView !== view) {
            this.state.data.spendView = view;
            setTimeout(() => this.renderSpendChart(), 0);
        }
    }

    switchInventoryView(view) {
        if (this.state.data.inventoryView !== view) {
            this.state.data.inventoryView = view;
            this.renderCharts();
        }
    }

    switchFocView(view) {
        if (this.state.data.focView !== view) {
            this.state.data.focView = view;
            setTimeout(() => this.renderCharts(), 0);
        }
    }

    switchTab(tab) {
        this.state.activeTab = tab;
        setTimeout(() => this.renderCharts(), 0);
    }

    toggleFilterDropdown(filterType) {
        if (this.state.data.activeFilter === filterType) {
            this.state.data.activeFilter = null;
        } else {
            this.state.data.activeFilter = filterType;
        }
    }

    setFilter(type, value) {
        this.state.data.filters[type] = value;
        this.state.data.activeFilter = null;
        // In a real app, this would trigger loadData() with filter parameters
        // For now, we just update the UI state
    }

    resetFilters() {
        this.state.data.filters = {
            period: 'Today',
            project: 'All Projects',
            client: 'All Clients',
            vendor: 'All Vendors',
            warehouse: 'All Warehouses',
            category: 'All Categories'
        };
        this.state.data.activeFilter = null;
    }

    formatCurrency(value) {
        if (value >= 10000000) {
            return (value / 10000000).toFixed(2) + " Cr";
        } else if (value >= 100000) {
            return (value / 100000).toFixed(2) + "L";
        } else if (value >= 1000) {
            return (value / 1000).toFixed(0) + "K";
        }
        return value.toString();
    }

    renderCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart) chart.destroy();
        });

        if (this.state.activeTab === 'money_flow' || this.state.activeTab === 'summary') {
            this.renderTrendChart();
            this.renderSpendChart();
            this.renderVendorChart();
        } else if (this.state.activeTab === 'inventory') {
            if (this.state.data.inventoryView === 'split') {
                this.renderInventoryChart();
            } else {
                this.renderAgingChart();
            }
            this.renderForecastChart();
        } else if (this.state.activeTab === 'foc') {
            if (this.state.data.focView === 'trend') {
                this.renderFocChart();
            } else if (this.state.data.focView === 'machine') {
                this.renderMachineChart();
            }
        } else if (this.state.activeTab === 'forecast') {
            this.renderForecastChart();
        }
    }

    renderFocChart() {
        if (!this.focChartRef.el) return;
        const ctx = this.focChartRef.el.getContext('2d');
        const data = this.state.data.foc_page.trend;

        this.charts.foc = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: 'FOC Cost',
                        data: data.foc_costs,
                        borderColor: '#ef4444',
                        backgroundColor: '#ef4444',
                        borderWidth: 2,
                        pointRadius: 3,
                        tension: 0.4,
                        yAxisID: 'y'
                    },
                    {
                        label: 'Revenue',
                        data: data.revenue,
                        borderColor: '#10b981',
                        backgroundColor: '#10b981',
                        borderWidth: 2,
                        pointRadius: 3,
                        tension: 0.4,
                        yAxisID: 'y1'
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    legend: { display: true, position: 'bottom' },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const val = context.raw;
                                return ` ${context.dataset.label} : ₹${val.toLocaleString()}`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        beginAtZero: true,
                        ticks: {
                            callback: (value) => value >= 1000 ? (value / 1000) + 'K' : value
                        },
                        grid: { borderDash: [5, 5], color: '#e2e8f0' }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        beginAtZero: true,
                        ticks: {
                            callback: (value) => value >= 100000 ? (value / 100000) + 'L' : value
                        },
                        grid: { drawOnChartArea: false }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    renderMachineChart() {
        if (!this.focChartRef.el) return;
        const ctx = this.focChartRef.el.getContext('2d');
        const data = this.state.data.foc_page.machines;

        this.charts.foc = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.map(m => m.name),
                datasets: [{
                    label: 'FOC Cost',
                    data: data.map(m => m.value),
                    backgroundColor: '#ef4444',
                    borderRadius: 4,
                    barThickness: 150
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'bottom' },
                    tooltip: {
                        callbacks: {
                            label: (context) => ` FOC Cost: ₹${context.raw.toLocaleString()}`
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: (value) => '₹' + (value / 1000) + 'K'
                        },
                        grid: { borderDash: [5, 5], color: '#e2e8f0' }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    renderBusinessForecastChart() {
        if (!this.businessForecastChartRef.el) return;
        const ctx = this.businessForecastChartRef.el.getContext('2d');
        const data = this.state.data.forecast_page;

        this.charts.businessForecast = new Chart(ctx, {
            type: 'line',
            data: {
                labels: data.labels,
                datasets: [
                    {
                        label: 'Projected Revenue',
                        data: data.revenue,
                        borderColor: '#2563eb',
                        backgroundColor: 'rgba(37, 99, 235, 0.1)',
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'Budget Target',
                        data: data.target,
                        borderColor: '#94a3b8',
                        borderDash: [5, 5],
                        fill: false,
                        tension: 0
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'bottom' }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: (value) => '₹' + (value / 100000) + 'L'
                        }
                    }
                }
            }
        });
    }

    renderForecastChart() {
        if (!this.forecastChartRef.el) return;
        const ctx = this.forecastChartRef.el.getContext('2d');

        this.charts.forecast = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Next 30 days', 'Next 60 days', 'Next 90 days'],
                datasets: [
                    {
                        label: 'Forecasted Purchase',
                        data: [3500000, 6800000, 9200000],
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.4)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 3
                    },
                    {
                        label: 'Committed Orders',
                        data: [2100000, 3900000, 5200000],
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.4)',
                        fill: true,
                        tension: 0.4,
                        pointRadius: 3
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            pointStyle: 'circle',
                            padding: 20
                        }
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: (context) => {
                                const val = context.raw;
                                return ` ${context.dataset.label}: ₹${(val / 100000).toFixed(2)}L`;
                            }
                        }
                    }
                },
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        stacked: true,
                        ticks: {
                            callback: (value) => '₹' + (value / 100000) + 'L'
                        },
                        grid: { borderDash: [5, 5], color: '#e2e8f0' }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    }

    renderAgingChart() {
        if (!this.inventoryChartRef.el) return;
        const ctx = this.inventoryChartRef.el.getContext('2d');
        const data = this.state.data.inventory_page.aging_data;

        this.charts.inventory = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: data.map(d => d.label),
                datasets: [{
                    label: 'Inventory Value',
                    data: data.map(d => d.value),
                    backgroundColor: data.map(d => d.color),
                    borderRadius: 5,
                    barThickness: 150
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: true, position: 'bottom' },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const val = context.raw;
                                return ` Inventory Value : ₹${(val / 100000).toFixed(2)}L`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: (value) => '₹' + (value / 100000) + 'L'
                        },
                        grid: { borderDash: [5, 5], color: '#e2e8f0' }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    renderInventoryChart() {
        if (!this.inventoryChartRef.el) return;
        const ctx = this.inventoryChartRef.el.getContext('2d');
        const data = this.state.data.inventory_page.split;

        this.charts.inventory = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: data.map(d => d.label),
                datasets: [{
                    data: data.map(d => d.value),
                    backgroundColor: data.map(d => d.color),
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const val = context.raw;
                                return ` ₹${(val / 100000).toFixed(2)}L (${((val / this.state.data.inventory_page.total_value) * 100).toFixed(1)}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    renderTrendChart() {
        if (!this.trendChartRef.el) return;
        const ctx = this.trendChartRef.el.getContext('2d');
        const labels = this.state.data.trends.map(t => t.month);
        const revenueData = this.state.data.trends.map(t => t.revenue);
        const spendData = this.state.data.trends.map(t => t.spend);

        this.charts.trend = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'revenue',
                        data: revenueData,
                        borderColor: '#2ecc71',
                        backgroundColor: 'rgba(46, 204, 113, 0.4)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 2,
                        pointBackgroundColor: '#fff',
                        pointBorderColor: '#2ecc71',
                        pointRadius: 4
                    },
                    {
                        label: 'spend',
                        data: spendData,
                        borderColor: '#e28169',
                        backgroundColor: 'rgba(226, 129, 105, 0.6)',
                        fill: true,
                        tension: 0.4,
                        borderWidth: 2,
                        pointBackgroundColor: '#fff',
                        pointBorderColor: '#e28169',
                        pointRadius: 4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        mode: 'index',
                        intersect: false,
                        callbacks: {
                            label: (context) => {
                                let label = context.dataset.label || '';
                                if (label) { label += ' : '; }
                                label += '₹' + this.formatCurrency(context.parsed.y);
                                return label;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 6000000,
                        ticks: {
                            stepSize: 1500000,
                            callback: (value) => value > 0 ? '₹' + (value / 100000) + 'L' : '₹0L'
                        },
                        grid: { borderDash: [5, 5], color: '#e2e8f0' }
                    },
                    x: { grid: { display: false } }
                }
            }
        });
    }

    renderSpendChart() {
        if (!this.spendChartRef.el) return;
        const ctx = this.spendChartRef.el.getContext('2d');

        // Destroy existing chart if it exists
        if (this.charts.spend) {
            this.charts.spend.destroy();
        }

        if (this.state.data.spendView === 'timeline') {
            const labels = ['Feb 3', 'Feb 4', 'Feb 5', 'Feb 6', 'Feb 7', 'Feb 8', 'Feb 9'];
            const data = [182000, 221000, 195000, 312000, 245000, 272000, 258000];

            this.charts.spend = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: labels,
                    datasets: [{
                        label: 'Spend Amount',
                        data: data,
                        backgroundColor: '#3498db',
                        borderRadius: 5,
                        barThickness: 35
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: (context) => 'Spend Amount: ₹' + this.formatCurrency(context.parsed.y)
                            }
                        }
                    },
                    scales: {
                        y: {
                            display: true,
                            ticks: {
                                callback: (value) => '₹' + (value / 1000) + 'K'
                            },
                            grid: { borderDash: [5, 5], color: '#e2e8f0' }
                        },
                        x: { display: true, grid: { display: false } }
                    }
                }
            });
        } else {
            // Category View (Pie Chart)
            const labels = ['Raw Material', 'Electronics', 'Mechanical', 'Services'];
            const data = [37, 27, 21, 14];
            const colors = ['#3b82f6', '#8b5cf6', '#06b6d4', '#10b981']; // Blue, Purple, Cyan, Green matching the image style

            this.charts.spend = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: colors,
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: true,
                            position: 'right',
                            labels: {
                                usePointStyle: true,
                                padding: 20,
                                font: { size: 12 }
                            }
                        },
                        tooltip: {
                            callbacks: {
                                label: (context) => {
                                    return context.label + ': ' + context.parsed + '%';
                                }
                            }
                        }
                    },
                    scales: {
                        y: { display: false },
                        x: { display: false }
                    }
                }
            });
        }
    }

    renderVendorChart() {
        if (!this.vendorChartRef.el) return;
        const ctx = this.vendorChartRef.el.getContext('2d');
        const labels = this.state.data.top_vendors.map(v => v.name);
        const data = this.state.data.top_vendors.map(v => v.value);

        this.charts.vendor = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Purchase Value',
                    data: data,
                    backgroundColor: '#9b59b6',
                    borderRadius: 5
                }]
            },
            options: {
                indexAxis: 'y',
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        callbacks: {
                            label: (context) => 'Purchase Value: ₹' + this.formatCurrency(context.parsed.y)
                        }
                    }
                },
                scales: {
                    x: {
                        ticks: {
                            callback: (value) => '₹' + (value / 10000000) + 'Cr'
                        },
                        grid: { borderDash: [5, 5], color: '#e2e8f0' }
                    },
                    y: { grid: { display: false } }
                }
            }
        });
    }
}

CEODashboard.template = "dashboard_ceo.Main";
registry.category("actions").add("dashboard_ceo.main", CEODashboard);
