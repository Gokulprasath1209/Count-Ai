from odoo import models, fields, api, _
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

class CEODashboard(models.Model):
    _name = 'ceo.dashboard'
    _description = 'CEO Dashboard'

    @api.model
    def get_dashboard_data(self):
        """ Returns aggregated data for the CEO dashboard, matching the mockup values """
        today = datetime.now()
        
        # Mockup Values
        revenue = 5200000 # 52.00L
        spend = 3900000   # 39.00L
        margin = 1300000  # 13.00L
        margin_pct = 25.0
        inventory_value = 10200000 # 1.02 Cr

        # Project Health
        projects = {
            'on_track': 8,
            'at_risk': 4,
            'over_budget': 2
        }

        # Approval Status
        approvals = {
            'pending': 3,
            'approved': 12,
            'rejected': 2,
            'blocked_value': 4500000 # 45L
        }
        
        # Bottlenecks (from Image 2)
        bottlenecks = [
            {'id': 'PRJ-2024-006', 'amount': 1500000, 'level': 'CFO', 'waiting': 3, 'status': 'Pending'},
            {'id': 'PRJ-2024-007', 'amount': 800000, 'level': 'CEO', 'waiting': 7, 'status': 'Pending'},
            {'id': 'PRJ-2024-008', 'amount': 2200000, 'level': 'Finance', 'waiting': 1, 'status': 'Pending'}
        ]

        # Trends
        trends = [
            {'month': 'Aug', 'revenue': 4100000, 'spend': 3100000},
            {'month': 'Sep', 'revenue': 4300000, 'spend': 3300000},
            {'month': 'Oct', 'revenue': 4700000, 'spend': 3500000},
            {'month': 'Nov', 'revenue': 5000000, 'spend': 3800000},
            {'month': 'Dec', 'revenue': 5300000, 'spend': 3975000}, # Matching image tooltip
            {'month': 'Jan', 'revenue': 5400000, 'spend': 4100000},
            {'month': 'Feb', 'revenue': 5200000, 'spend': 3900000}
        ]

        # Top Vendors
        top_vendors = [
            {'name': 'Acme Supplies', 'value': 12000000},
            {'name': 'Tech Components', 'value': 10000000},
            {'name': 'MechParts Ltd', 'value': 9000000},
            {'name': 'Electronics Hub', 'value': 8000000},
            {'name': 'Global Materials', 'value': 7500000},
            {'name': 'Precision Tools', 'value': 6500000},
            {'name': 'Industrial Goods', 'value': 6000000},
            {'name': 'Quality Services', 'value': 5500000}
        ]

        return {
            'revenue': revenue,
            'spend': spend,
            'margin': margin,
            'margin_pct': margin_pct,
            'inventory': inventory_value,
            'projects': projects,
            'approvals': approvals,
            'bottlenecks': bottlenecks,
            'trends': trends,
            'top_vendors': top_vendors,
            'last_updated': today.strftime('%b %d, %Y - %I:%M %p')
        }
